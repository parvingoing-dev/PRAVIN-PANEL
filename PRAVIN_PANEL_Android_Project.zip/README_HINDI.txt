PRAVIN PANEL — Android Studio Project

यह एक सुरक्षित Free Fire practice-guide ऐप का शुरुआती प्रोजेक्ट है।
इसमें Headshot Practice, Sensitivity Guide, HUD Layout, Weapon Practice
और Account Safety की जानकारी है।

महत्वपूर्ण:
- यह गेम को modify नहीं करता और Free Fire के साथ connect नहीं होता।
- इसमें Aimbot, ESP, auto-headshot, anti-ban bypass, scripts या macros नहीं हैं।
- कोई ऐप account ban न होने की guarantee नहीं दे सकता।
- ऐप कोई password, OTP या UID नहीं माँगता।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. Android Studio में "Open" चुनें और इस ZIP को extract करके
   PRAVIN_PANEL_Android_Project फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें। जरूरत पड़ने पर Android SDK 35 इंस्टॉल करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK बनने पर Android Studio के notification में "locate" दबाकर APK पाएँ।
6. APK केवल अपने भरोसेमंद डिवाइस पर इंस्टॉल करें।

ज़रूरत: Android Studio, JDK 17 और इंटरनेट (पहली Gradle sync के लिए)।
