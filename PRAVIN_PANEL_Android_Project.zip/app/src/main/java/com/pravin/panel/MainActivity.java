package com.pravin.panel;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(10, 10, 12);
    private final int card = Color.rgb(27, 26, 25);
    private final int gold = Color.rgb(222, 184, 92);
    private final int white = Color.rgb(245, 242, 235);
    private LinearLayout root;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("PRAVIN PANEL", 28, gold, true);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand);
        TextView subtitle = text("FREE FIRE • TRAINING COMPANION", 12, white, true);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setLetterSpacing(0.08f);
        addGap(root, 6);
        root.addView(subtitle);
        addGap(root, 20);

        LinearLayout hero = panel();
        TextView heroTitle = text("WELCOME, PLAYER", 18, gold, true);
        hero.addView(heroTitle);
        TextView heroDesc = text("Practice smart. Play fair. Improve every match.", 14, white, false);
        hero.addView(heroDesc);
        root.addView(hero);
        addGap(root, 14);

        addSection("TRAINING TOOLS");
        addCard("🎯  Headshot Practice", "Safe drills to improve aim and drag control.",
                "Start with the training ground. Keep your crosshair near upper-body level, make small controlled movements, and practise consistently. This is guidance only; it does not control the game.");
        addCard("⚙️  Sensitivity Guide", "Learn how to test and tune your own settings.",
                "Change one sensitivity setting at a time. Test it in the training area, then adjust gradually. There is no universal best setting for every phone or player.");
        addCard("▦  HUD Layout Guide", "Plan a comfortable, easy-to-reach button layout.",
                "Keep important controls comfortable for your fingers. Make small changes, practise with the layout, and keep the arrangement that feels natural.");
        addCard("🔫  Weapon Practice", "Build familiarity with recoil and weapon handling.",
                "Practise one weapon at a time. Learn its range and firing rhythm in the official training area. Use only normal in-game controls.");
        addCard("📈  Match Improvement", "Track practice goals and review your progress.",
                "After each session, note one thing that improved and one skill to practise next. Focus on consistency, positioning, and teamwork.");

        addSection("ACCOUNT SAFETY");
        addCard("🛡️  ID Safety Checklist", "Protect your account from scams and risky tools.",
                "Never share your password or verification code. Avoid modified game clients, scripts, injectors, and unofficial panels. Use the game's official account and recovery options. No third-party panel can guarantee that an account will never be banned.");
        addCard("🔒  Safe Play Rules", "Keep your game and account within official rules.",
                "Use the official game app and permitted settings only. Do not use aimbots, ESP, macros, anti-ban bypasses, or tools that modify gameplay.");

        addGap(root, 12);
        TextView footer = text("PRAVIN PANEL  •  VERSION 1.0\\nIndependent practice guide — not affiliated with Garena.", 11,
                Color.rgb(165, 160, 150), false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);
    }

    private void addSection(String title) {
        TextView t = text(title, 13, gold, true);
        t.setLetterSpacing(0.12f);
        root.addView(t);
        addGap(root, 8);
    }

    private void addCard(String title, String desc, String details) {
        LinearLayout box = panel();
        TextView t = text(title, 17, gold, true);
        box.addView(t);
        addGap(box, 5);
        box.addView(text(desc, 13, white, false));
        addGap(box, 10);
        Button b = new Button(this);
        b.setText("OPEN GUIDE");
        b.setTextColor(Color.BLACK);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(round(gold, 12));
        b.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(details)
                .setPositiveButton("GOT IT", (d, w) -> d.dismiss())
                .show());
        box.addView(b);
        root.addView(box);
        addGap(root, 12);
    }

    private LinearLayout panel() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(15), dp(16), dp(15));
        l.setBackground(round(card, 16));
        return l;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private void addGap(LinearLayout l, int h) {
        View v = new View(this);
        l.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
